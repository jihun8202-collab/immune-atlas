#define AppVersion "1.0.0"
[Setup]
AppId={{7292D62C-4F06-40AC-8426-26E80350B446}
AppName=Immune Atlas
AppVersion={#AppVersion}
AppVerName=이뮨 아틀라스 1.0.0 Beta 3
AppPublisher=Immune Atlas
AppPublisherURL=https://immune-atlas-laboratory.h2h22.chatgpt.site
DefaultDirName={localappdata}\Programs\ImmuneAtlas
DefaultGroupName=Immune Atlas
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\release
OutputBaseFilename=ImmuneAtlas_Setup_1.0.0_Beta3
SetupIconFile=icon.ico
UninstallDisplayIcon={app}\ImmuneAtlas.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes
RestartApplications=no
UninstallDisplayName=이뮨 아틀라스 · Immune Atlas
[Languages]
Name: "korean"; MessagesFile: "compiler:Languages\Korean.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"
[Tasks]
Name: "desktopicon"; Description: "바탕 화면에 바로 가기 만들기"; Flags: unchecked
[Files]
Source: "..\build\app\ImmuneAtlas\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\이뮨 아틀라스"; Filename: "{app}\ImmuneAtlas.exe"
Name: "{autodesktop}\이뮨 아틀라스"; Filename: "{app}\ImmuneAtlas.exe"; Tasks: desktopicon
[Run]
Filename: "{app}\ImmuneAtlas.exe"; Description: "이뮨 아틀라스 시작"; Flags: nowait postinstall skipifsilent
[Code]
function InitializeSetup(): Boolean;
var Version: String;
begin
  Result := True;
  if not (RegQueryStringValue(HKLM32, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E0DE-9E83-4B59-8A81-2FE0C12C2765}', 'pv', Version) or
    RegQueryStringValue(HKCU, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E0DE-9E83-4B59-8A81-2FE0C12C2765}', 'pv', Version) or
    DirExists(ExpandConstant('{commonpf32}\Microsoft\EdgeWebView\Application'))) then
  begin
    MsgBox('이 앱은 Microsoft Edge WebView2 Runtime이 필요합니다. Microsoft 공식 WebView2 다운로드 페이지에서 Evergreen Runtime을 설치한 후 다시 실행하세요.', mbInformation, MB_OK);
    Result := False;
  end;
end;
