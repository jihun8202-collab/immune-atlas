"""Immune Atlas: offline WebView2 desktop shell and verified cloud updater."""
from pathlib import Path
import sys, os, json, threading, tempfile, hashlib, re, subprocess, time
from urllib.request import Request, urlopen
from urllib.parse import urlparse, urljoin

VERSION='1.0.0-beta.3'
UPDATE_CATALOG='https://api.github.com/repos/jihun8202-collab/immune-atlas/releases'
ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent.parent))
DATA=Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / 'ImmuneAtlas'
TAG=re.compile(r'^immune-atlas-v(\d+)\.(\d+)\.(\d+)(?:-beta\.(\d+))?$')

def version_key(tag):
    m=TAG.fullmatch(tag)
    if not m: return None
    return tuple(map(int,m.groups()[:3]))+(1 if m[4] is None else 0,int(m[4] or 0))

def request_json(url):
    req=Request(url,headers={'User-Agent':'ImmuneAtlas/1.0','Accept':'application/vnd.github+json'})
    with urlopen(req,timeout=20) as response:
        return json.loads(response.read(4_000_000))

def select_release(releases,channel='beta'):
    if channel not in ('stable','beta'): raise ValueError('Unknown update channel')
    valid=[]
    for release in releases:
        key=version_key(release.get('tag_name',''))
        if not key or release.get('draft') or (channel=='stable' and (release.get('prerelease') or key[3]==0)): continue
        names={a.get('name') for a in release.get('assets',[])}
        if 'SHA256SUMS.txt' not in names or not any(re.fullmatch(r'ImmuneAtlas_Setup_[\w.]+\.exe',n or '') for n in names): continue
        valid.append((key,release))
    return max(valid,key=lambda x:x[0])[1] if valid else None

def github_releases():
    releases=request_json(UPDATE_CATALOG)
    if not isinstance(releases,list): raise ValueError('GitHub 릴리스 목록 형식 오류')
    normalized=[]
    for release in releases:
        assets=[{'name':a.get('name',''),'url':a.get('browser_download_url',''),'sha256':(a.get('digest') or '').removeprefix('sha256:').lower()} for a in release.get('assets',[])]
        sums=next((a for a in assets if a['name']=='SHA256SUMS.txt'),None)
        if sums and any(not a['sha256'] for a in assets):
            try:
                with urlopen(Request(sums['url'],headers={'User-Agent':'ImmuneAtlas/1.0'}),timeout=20) as response:
                    if urlparse(response.geturl()).scheme=='https' and urlparse(response.geturl()).hostname=='release-assets.githubusercontent.com':
                        rows=response.read(100_000).decode('utf-8').splitlines()
                        for asset in assets:
                            row=next((line for line in rows if line.strip().endswith('  '+asset['name']) or line.strip().endswith(' *'+asset['name'])),None)
                            if row: asset['sha256']=row.split()[0].lower()
            except Exception: pass
        normalized.append({**release,'changes':release.get('body') or '', 'assets':assets})
    return normalized

class Api:
    def __init__(self,data=DATA):
        self._data=Path(data);self._data.mkdir(parents=True,exist_ok=True);self._ready=None;self._window=None;self._lock=threading.Lock()
    def read_experiment(self):
        p=self._data/'experiment.json'
        if not p.exists(): return None
        if p.stat().st_size>8_000_000: return None
        return json.loads(p.read_text(encoding='utf-8'))
    def save_experiment(self,payload):
        if not isinstance(payload,dict) or payload.get('format')!='immune-atlas-experiment': raise ValueError('Invalid experiment')
        raw=json.dumps(payload,ensure_ascii=False,allow_nan=False)
        if len(raw.encode('utf8'))>8_000_000: raise ValueError('Experiment is too large')
        with self._lock:
            p=self._data/'experiment.tmp';p.write_text(raw,encoding='utf-8');p.replace(self._data/'experiment.json')
        return True
    def check_updates(self,channel='beta'):
        release=select_release(github_releases(),channel)
        return {'available':bool(release and version_key(release['tag_name'])>version_key('immune-atlas-v'+VERSION)), 'release':release,'channel':channel}
    def download_update(self,tag):
        if not TAG.fullmatch(tag): raise ValueError('Invalid release tag')
        release=next((r for r in github_releases() if r.get('tag_name')==tag),None)
        if not release or not select_release([release]): raise ValueError('설치 파일 또는 체크섬이 업데이트 목록에 없습니다.')
        setup=next(a for a in release['assets'] if re.fullmatch(r'ImmuneAtlas_Setup_[\w.]+\.exe',a.get('name','')))
        def fetch(asset,limit):
            url=asset.get('url','')
            if not url.startswith('https://github.com/jihun8202-collab/immune-atlas/releases/download/') or '/' in asset['name'] or '\\' in asset['name']: raise ValueError('잘못된 설치 파일 위치입니다.')
            with urlopen(Request(url,headers={'User-Agent':'ImmuneAtlas/1.0'}),timeout=60) as res:
                if urlparse(res.geturl()).scheme!='https' or urlparse(res.geturl()).hostname not in ('release-assets.githubusercontent.com','objects.githubusercontent.com'): raise ValueError('안전한 HTTPS 업데이트 주소가 아닙니다.')
                data=res.read(limit+1)
            if len(data)>limit: raise ValueError('Update exceeds size limit')
            return data
        expected_hash=setup.get('sha256','').lower()
        if not re.fullmatch(r'[a-f0-9]{64}',expected_hash): raise ValueError('잘못된 SHA-256 체크섬입니다.')
        blob=fetch(setup,160_000_000)
        if hashlib.sha256(blob).hexdigest()!=expected_hash: raise ValueError('SHA-256 verification failed')
        folder=self._data/'updates';folder.mkdir(exist_ok=True);target=folder/setup['name'];target.write_bytes(blob);self._ready=(target,expected_hash)
        return {'ready':True,'message':'설치 파일 다운로드와 SHA-256 검증을 완료했습니다.'}
    def install_update(self):
        if not self._ready: raise ValueError('먼저 설치 파일을 다운로드하세요.')
        p,digest=self._ready
        if hashlib.sha256(p.read_bytes()).hexdigest()!=digest: raise ValueError('설치 파일이 변경되었습니다.')
        subprocess.Popen([str(p),'/SP-'],cwd=str(p.parent))
        if self._window: self._window.destroy()
        return True

def main():
    import webview
    smoke='--smoke-test' in sys.argv
    if smoke:
        folder=Path(sys.argv[sys.argv.index('--smoke-test')+1]).resolve();folder.mkdir(parents=True,exist_ok=True)
        api=Api(folder/'profile')
    else: api=Api()
    webview.settings['ALLOW_DOWNLOADS']=True
    webview.settings['ALLOW_FILE_URLS']=False
    webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER']=True
    webview.settings['OPEN_DEVTOOLS_IN_DEBUG']=False
    window=webview.create_window('이뮨 아틀라스 · Immune Atlas 1.0 Beta',str(ROOT/'dist'/'index.html'),js_api=api,width=1500,height=1000,min_size=(850,650),background_color='#F5F5EF',text_select=True,zoomable=True)
    api._window=window
    if smoke:
        def verify():
            try:
                for _ in range(80):
                    result=window.evaluate_js('window.immuneAtlas ? {version:window.immuneAtlas.version,renderer:window.immuneAtlas.renderer,body:document.body.innerText.includes("면역 반응 실험실"),organs:document.querySelectorAll("[data-organ]").length} : null')
                    if result: break
                    time.sleep(.25)
                if not result: raise RuntimeError('App did not initialize')
                window.evaluate_js('document.querySelector("#step").click()')
                result['after_step']=window.evaluate_js('window.immuneAtlas.engine.time')
                result['errors']=window.evaluate_js('document.querySelector("#model-status").textContent')
                result['web_hash']=hashlib.sha256((ROOT/'dist'/'engine.js').read_bytes()).hexdigest()
                (folder/'desktop-smoke.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
            except Exception as exc:
                (folder/'desktop-smoke-error.txt').write_text(str(exc),encoding='utf8')
            finally: window.destroy()
        window.events.loaded+=verify
    webview.start(gui='edgechromium',http_server=True,private_mode=False,storage_path=str(api._data/'webview'),icon=str(ROOT/'desktop'/'icon.ico'))

if __name__=='__main__': main()
