from pathlib import Path
import subprocess,sys,os,hashlib,zipfile,json,shutil
ROOT=Path(__file__).resolve().parent.parent
os.chdir(ROOT)
web_stage=ROOT/'build/web-payload'
shutil.copytree(ROOT/'dist',web_stage,dirs_exist_ok=True,ignore=shutil.ignore_patterns('downloads'))
# Logo is drawn from the same original geometric design as dist/logo.svg.
from PIL import Image,ImageDraw
im=Image.new('RGBA',(256,256));d=ImageDraw.Draw(im);d.rounded_rectangle((0,0,255,255),radius=68,fill='#174c46');d.ellipse((43,38,209,209),fill='#bce5cb');d.ellipse((85,70,170,161),fill='#568b79');d.ellipse((110,92,141,124),fill='#f4c486');d.ellipse((56,119,72,135),fill='#f8fae7');d.ellipse((165,155,185,175),fill='#f8fae7');im.save('desktop/icon.ico',sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])
subprocess.run([sys.executable,'-m','PyInstaller','--noconfirm','--clean','--windowed','--onedir','--name','ImmuneAtlas','--icon',str(ROOT/'desktop/icon.ico'),'--add-data',str(web_stage)+';dist','--add-data',str(ROOT/'desktop/icon.ico')+';desktop','--collect-all','webview','--exclude-module','PyQt5','--exclude-module','PySide6','--distpath','build/app','--workpath','build/pyinstaller','--specpath','build','desktop/main.py'],check=True)
compiler=Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Inno Setup 6'/'ISCC.exe'
if not compiler.exists(): compiler=Path('C:/Program Files (x86)/Inno Setup 6/ISCC.exe')
subprocess.run([str(compiler),'desktop/installer.iss'],check=True)
release=ROOT/'release';zip_path=release/'ImmuneAtlas_Update_1.0.0_Beta4.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,6) as z:
    base=ROOT/'build/app/ImmuneAtlas'
    for p in base.rglob('*'):
        if p.is_file(): z.write(p,p.relative_to(base))
assets=[release/'ImmuneAtlas_Setup_1.0.0_Beta4.exe',zip_path]
(release/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in assets),encoding='utf8')
print(json.dumps({'assets':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in assets]},indent=2))
